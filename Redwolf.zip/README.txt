# WEBSITE CODE EXTRACTIONS REPORT 

Website: https://redwolfhacker.online/index.php
EXTRACTION DATE: 5157551.49835569

## Summary:
- HTML FILES: 1
- CSS FILES: 5
- INLINE CSS BLOCKS: 7
- JAVASCRIPT FILES: 2
- INLINE JAVASCRIPT BLOCKS: 3
- API ENDPOINTS FOUND: 0
- IMAGES FOUND: 19

## Files Structure:
- index.html (Main HTML file)
- css/ (All CSS files)
- js/ (All JavaScript files)
- api_endpoints.txt (List of found API endpoints)

## Note:
This extraction includes all publicly accessible code from the website.
Some dynamic content loaded via AJAX may not be included.
